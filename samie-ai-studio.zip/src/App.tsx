/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wand2, Video, Image as ImageIcon, Sparkles, Play, 
  Upload, Scissors, Layers, Zap, CheckCircle2, 
  ChevronRight, Menu, X, Film, SlidersHorizontal
} from 'lucide-react';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#00f0ff] selection:text-black font-sans overflow-x-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 bg-[#050505]/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex-shrink-0 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00f0ff] to-[#ff00ff] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-2xl tracking-tight">samie</span>
            </div>
            
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <a href="#studio" className="hover:text-[#00f0ff] transition-colors px-3 py-2 rounded-md text-sm font-medium">Studio</a>
                <a href="#workflows" className="hover:text-[#00f0ff] transition-colors px-3 py-2 rounded-md text-sm font-medium">AI Video Workflows</a>
                <a href="#features" className="hover:text-[#00f0ff] transition-colors px-3 py-2 rounded-md text-sm font-medium">Features</a>
                <a href="#examples" className="hover:text-[#00f0ff] transition-colors px-3 py-2 rounded-md text-sm font-medium">Examples</a>
              </div>
            </div>
            
            <div className="hidden md:block">
              <button className="bg-white text-black hover:bg-[#00f0ff] transition-colors px-6 py-2.5 rounded-full font-medium text-sm cursor-pointer">
                Start Free
              </button>
            </div>

            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300 hover:text-white p-2 cursor-pointer">
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-[#0a0a0a] border-b border-white/10"
            >
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="#studio" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:text-[#00f0ff]">Studio</a>
                <a href="#workflows" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:text-[#00f0ff]">Workflows</a>
                <a href="#features" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:text-[#00f0ff]">Features</a>
                <a href="#examples" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium hover:text-[#00f0ff]">Examples</a>
                <button className="w-full mt-4 bg-gradient-to-r from-[#00f0ff] to-[#ff00ff] text-white px-6 py-3 rounded-full font-medium cursor-pointer">
                  Start Free
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#00f0ff]/20 rounded-full blur-[120px] opacity-50 pointer-events-none"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#ff00ff]/20 rounded-full blur-[100px] opacity-50 pointer-events-none ml-40 mt-20"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
              <Sparkles className="w-4 h-4 text-[#00f0ff]" />
              <span className="text-sm font-medium text-gray-300">Powered by Gemini 3.1 Pro + Anti-Gravity</span>
            </div>
            
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter mb-6 leading-tight">
              Generate, Edit & Enhance <br className="hidden md:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f0ff] via-white to-[#ff00ff]">
                Any Photo or Video
              </span>
            </h1>
            
            <p className="mt-6 text-xl text-gray-400 max-w-3xl mx-auto mb-10">
              The ultimate AI studio. Just describe what you want, and Samie brings your imagination to life with cinematic quality and perfect precision.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button className="w-full sm:w-auto px-8 py-4 rounded-full bg-white text-black font-semibold text-lg hover:scale-105 transition-transform flex items-center justify-center gap-2 cursor-pointer">
                Start Creating Free <ChevronRight className="w-5 h-5" />
              </button>
              <button className="w-full sm:w-auto px-8 py-4 rounded-full bg-white/10 text-white border border-white/20 font-semibold text-lg hover:bg-white/20 transition-colors flex items-center justify-center gap-2 cursor-pointer">
                <Play className="w-5 h-5" /> Watch Demo
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Interactive Studio Demo */}
      <section id="studio" className="py-20 relative z-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <InteractiveStudio />
        </div>
      </section>

      {/* AI Video Workflows */}
      <section id="workflows" className="py-24 bg-[#0a0a0a] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Dedicated AI Video Workflows</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">Professional editing capabilities powered by natural language. No timeline required.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <WorkflowCard 
              icon={<Film className="w-8 h-8 text-[#00f0ff]" />}
              title="Auto Story Editor"
              desc="Turn hours of raw footage into a viral short. Samie finds the best moments, adds captions, and syncs to trending music."
            />
            <WorkflowCard 
              icon={<Wand2 className="w-8 h-8 text-[#ff00ff]" />}
              title="Motion Brush Editor"
              desc="Select any object in a video and type to change it. 'Make the car red', 'Change the sky to sunset', or 'Remove the person'."
            />
            <WorkflowCard 
              icon={<Scissors className="w-8 h-8 text-[#00f0ff]" />}
              title="Smart Re-cut & Remix"
              desc="Re-edit existing videos using natural language. 'Make it 15 seconds shorter', 'Focus more on the product', 'Change the pacing'."
            />
          </div>

          <div className="mt-12 p-8 rounded-2xl bg-gradient-to-r from-[#00f0ff]/10 to-[#ff00ff]/10 border border-white/10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h3 className="font-display text-2xl font-bold mb-2">Plus Bonus Workflows</h3>
              <p className="text-gray-400">Perfect your content with one-click AI tools.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Badge text="Perfect Lip-Sync" />
              <Badge text="Background Replace" />
              <Badge text="AI Slow-Mo" />
              <Badge text="Cinematic Color Grade" />
            </div>
          </div>
        </div>
      </section>

      {/* Core Features */}
      <section id="features" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">Everything you need to create masterpiece content.</h2>
              <p className="text-gray-400 text-lg mb-8">Samie combines state-of-the-art generation models with precise editing controls, giving you unprecedented creative freedom.</p>
              
              <div className="space-y-6">
                <FeatureRow icon={<Zap />} title="Real-time Generation" desc="See your ideas come to life instantly with our optimized inference engine." />
                <FeatureRow icon={<Layers />} title="Multi-modal Understanding" desc="Mix text, images, and video prompts to guide the AI exactly how you want." />
                <FeatureRow icon={<SlidersHorizontal />} title="Granular Control" desc="Adjust lighting, camera angles, style, and motion intensity with simple sliders." />
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#00f0ff]/20 to-[#ff00ff]/20 blur-3xl rounded-full"></div>
              <img src="https://picsum.photos/seed/cyberpunk/800/800" alt="Samie Interface" className="relative rounded-2xl border border-white/10 shadow-2xl" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      </section>

      {/* Examples Gallery */}
      <section id="examples" className="py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Made with Samie</h2>
            <p className="text-gray-400 text-lg">Just describe what you want.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <GalleryItem img="https://picsum.photos/seed/neoncity/600/800" prompt="Cinematic drone shot of a neon cyberpunk city in the rain, 8k resolution, photorealistic" />
            <GalleryItem img="https://picsum.photos/seed/portrait/600/800" prompt="Studio portrait of a woman with glowing cyan makeup, dramatic lighting" />
            <GalleryItem img="https://picsum.photos/seed/abstract/600/800" prompt="Abstract liquid metal flowing in zero gravity, magenta and cyan reflections" />
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Simple Pricing</h2>
            <p className="text-gray-400 text-lg">Start for free, upgrade when you need more power.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard 
              name="Free" 
              price="$0" 
              desc="Perfect for trying out Samie."
              features={['50 credits per month', 'Standard resolution', 'Basic editing tools', 'Community support']}
            />
            <PricingCard 
              name="Pro" 
              price="$29" 
              desc="For creators and professionals."
              isPopular
              features={['1000 credits per month', '4K Video & 8K Images', 'Advanced AI Workflows', 'Commercial license', 'Priority support']}
            />
            <PricingCard 
              name="Enterprise" 
              price="Custom" 
              desc="For teams and high-volume needs."
              features={['Unlimited credits', 'Custom model fine-tuning', 'API access', 'Dedicated account manager', 'SSO & advanced security']}
            />
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#00f0ff]/20 to-[#ff00ff]/20"></div>
        <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
          <h2 className="font-display text-5xl md:text-6xl font-bold mb-6">Ready to create the impossible?</h2>
          <p className="text-xl text-gray-300 mb-10">Join thousands of creators using Samie to push the boundaries of visual storytelling.</p>
          <button className="px-10 py-5 rounded-full bg-white text-black font-bold text-xl hover:scale-105 transition-transform shadow-[0_0_40px_rgba(0,240,255,0.3)] cursor-pointer">
            Start Creating for Free
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#050505] border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#00f0ff]" />
            <span className="font-display font-bold text-xl">samie</span>
          </div>
          <div className="flex gap-6 text-sm text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Twitter</a>
            <a href="#" className="hover:text-white transition-colors">Discord</a>
          </div>
          <div className="text-sm text-gray-500">
            © 2026 Samie AI. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

// Subcomponents

function InteractiveStudio() {
  const [activeTab, setActiveTab] = useState('generate');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleGenerate = () => {
    if (!prompt) return;
    setIsGenerating(true);
    setResult(null);
    
    // Simulate generation
    setTimeout(() => {
      setIsGenerating(false);
      setResult(`https://picsum.photos/seed/${encodeURIComponent(prompt) || 'cyber'}/800/450`);
    }, 2500);
  };

  return (
    <div className="bg-[#111] rounded-3xl border border-white/10 shadow-2xl overflow-hidden flex flex-col md:flex-row">
      {/* Controls */}
      <div className="w-full md:w-2/5 p-6 md:p-8 border-b md:border-b-0 md:border-r border-white/10 flex flex-col">
        <div className="flex bg-white/5 rounded-lg p-1 mb-6">
          <button 
            onClick={() => setActiveTab('generate')}
            className={`flex-1 py-2 text-sm font-medium rounded-md flex items-center justify-center gap-2 transition-colors cursor-pointer ${activeTab === 'generate' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
          >
            <Wand2 className="w-4 h-4" /> Generate
          </button>
          <button 
            onClick={() => setActiveTab('edit')}
            className={`flex-1 py-2 text-sm font-medium rounded-md flex items-center justify-center gap-2 transition-colors cursor-pointer ${activeTab === 'edit' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
          >
            <Video className="w-4 h-4" /> Edit
          </button>
          <button 
            onClick={() => setActiveTab('enhance')}
            className={`flex-1 py-2 text-sm font-medium rounded-md flex items-center justify-center gap-2 transition-colors cursor-pointer ${activeTab === 'enhance' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
          >
            <Sparkles className="w-4 h-4" /> Enhance
          </button>
        </div>

        <div className="flex-1 flex flex-col">
          <label className="text-sm font-medium text-gray-300 mb-2">
            {activeTab === 'generate' ? 'Describe what you want to see' : 
             activeTab === 'edit' ? 'How should we edit this video?' : 
             'What enhancements do you need?'}
          </label>
          <textarea 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              activeTab === 'generate' ? "A cinematic shot of a neon-lit street in Tokyo, raining, reflections..." :
              activeTab === 'edit' ? "Change the background to a sunset beach, make it cinematic..." :
              "Upscale to 4k, fix lighting, remove background noise..."
            }
            className="w-full h-32 bg-black/50 border border-white/10 rounded-xl p-4 text-white placeholder-gray-600 focus:outline-none focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] resize-none transition-all"
          />
          
          {activeTab !== 'generate' && (
            <button className="mt-4 w-full py-3 border border-dashed border-white/20 rounded-xl text-gray-400 hover:text-white hover:border-white/40 transition-colors flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4" /> Upload Media
            </button>
          )}
        </div>

        <button 
          onClick={handleGenerate}
          disabled={isGenerating || !prompt}
          className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-[#00f0ff] to-[#ff00ff] text-white font-bold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
        >
          {isGenerating ? (
            <>
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                <Sparkles className="w-5 h-5" />
              </motion.div>
              Processing...
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" /> Generate Now
            </>
          )}
        </button>
      </div>

      {/* Preview */}
      <div className="w-full md:w-3/5 bg-black p-4 flex items-center justify-center min-h-[300px] md:min-h-0 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {isGenerating ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-4"
            >
              <div className="w-16 h-16 rounded-full border-4 border-[#00f0ff]/20 border-t-[#00f0ff] animate-spin"></div>
              <p className="text-[#00f0ff] font-medium animate-pulse">Synthesizing pixels...</p>
            </motion.div>
          ) : result ? (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="w-full h-full relative group rounded-xl overflow-hidden"
            >
              <img src={result} alt="Generated result" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button className="p-3 bg-white/20 backdrop-blur-md rounded-full hover:bg-white/40 transition-colors cursor-pointer">
                  <Play className="w-6 h-6 text-white" />
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="empty"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="text-center text-gray-600 flex flex-col items-center gap-3"
            >
              <ImageIcon className="w-12 h-12 opacity-50" />
              <p>Your masterpiece will appear here</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function WorkflowCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="bg-[#111] border border-white/5 p-8 rounded-2xl hover:border-[#00f0ff]/30 transition-colors group">
      <div className="mb-6 p-4 bg-black rounded-xl inline-block group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="font-display text-2xl font-bold mb-3">{title}</h3>
      <p className="text-gray-400 leading-relaxed">{desc}</p>
    </div>
  );
}

function Badge({ text }: { text: string }) {
  return (
    <span className="px-4 py-2 rounded-full bg-black/50 border border-white/10 text-sm font-medium text-gray-300">
      {text}
    </span>
  );
}

function FeatureRow({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#00f0ff]/10 flex items-center justify-center text-[#00f0ff]">
        {icon}
      </div>
      <div>
        <h4 className="text-xl font-bold mb-1">{title}</h4>
        <p className="text-gray-400">{desc}</p>
      </div>
    </div>
  );
}

function GalleryItem({ img, prompt }: { img: string, prompt: string }) {
  return (
    <div className="relative group rounded-2xl overflow-hidden aspect-[3/4]">
      <img src={img} alt={prompt} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" referrerPolicy="no-referrer" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
        <p className="text-sm font-medium text-white line-clamp-3">"{prompt}"</p>
      </div>
    </div>
  );
}

function PricingCard({ name, price, desc, features, isPopular }: { name: string, price: string, desc: string, features: string[], isPopular?: boolean }) {
  return (
    <div className={`relative bg-[#111] rounded-3xl p-8 border ${isPopular ? 'border-[#00f0ff]' : 'border-white/10'} flex flex-col`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#00f0ff] text-black text-xs font-bold uppercase tracking-wider rounded-full">
          Most Popular
        </div>
      )}
      <h3 className="text-2xl font-display font-bold mb-2">{name}</h3>
      <p className="text-gray-400 text-sm mb-6 h-10">{desc}</p>
      <div className="mb-8">
        <span className="text-5xl font-bold font-display">{price}</span>
        {price !== 'Custom' && <span className="text-gray-500">/mo</span>}
      </div>
      <button className={`w-full py-3 rounded-xl font-bold mb-8 transition-colors cursor-pointer ${isPopular ? 'bg-white text-black hover:bg-gray-200' : 'bg-white/10 text-white hover:bg-white/20'}`}>
        Get Started
      </button>
      <div className="space-y-4 flex-1">
        {features.map((f, i) => (
          <div key={i} className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#00f0ff] shrink-0" />
            <span className="text-sm text-gray-300">{f}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
